-- ============================================================
-- SQL PATCH UPDATE UNTUK CPANEL PHPMYADMIN
-- Database: ukkra191_khusus_ukk
-- ============================================================

-- 1. Tambah kolom OTP di tabel password_reset_tokens
ALTER TABLE password_reset_tokens ADD otp VARCHAR(10) NULL AFTER 	oken;

-- 2. Tambah kolom lampiran foto/file & penanganan PIC di complaints
ALTER TABLE complaints ADD ile_path VARCHAR(255) NULL AFTER photo_path;
ALTER TABLE complaints ADD handler_photo_path VARCHAR(255) NULL AFTER handler_id;
ALTER TABLE complaints ADD handler_file_path VARCHAR(255) NULL AFTER handler_photo_path;
ALTER TABLE complaints ADD handler_note TEXT NULL AFTER handler_file_path;

-- 3. Tambahkan Ruang Wijaya Kusuma jika belum ada
INSERT INTO ooms (oom_name, capacity, location, pic_id, is_active, created_at, updated_at)
SELECT 'Ruang Wijaya Kusuma', 60, 'Gedung Utama Lantai 2', id, 1, NOW(), NOW()
FROM users WHERE username = 'pic2' LIMIT 1
ON DUPLICATE KEY UPDATE oom_name = oom_name;

-- 4. Update nama PIC 1 dan PIC 2
UPDATE users SET ullname = 'PIC 1 (Ruang Teori & Kelas)' WHERE username = 'pic1';
UPDATE users SET ullname = 'PIC 2 (Fasilitas Selain Lab & Kelas)' WHERE username = 'pic2';

-- 5. Buat / Pastikan PIC 3 (Udin Frimawan) ada
INSERT INTO users (username, ullname, phone_number, password, ole_id, created_at, updated_at)
SELECT 'pic3', 'Udin Frimawan', '6285550003333', '\\\.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', r.id, NOW(), NOW()
FROM oles r WHERE r.role_name = 'PIC Ruang' LIMIT 1
ON DUPLICATE KEY UPDATE ullname = 'Udin Frimawan';

-- 6. Update relasi Ruangan ke PIC masing-masing:
-- Seluruh Lab ke Udin Frimawan (pic3)
UPDATE ooms SET pic_id = (SELECT id FROM users WHERE username = 'pic3' LIMIT 1) WHERE oom_name LIKE 'Lab%';

-- Seluruh Ruang Teori ke PIC 1
UPDATE ooms SET pic_id = (SELECT id FROM users WHERE username = 'pic1' LIMIT 1) WHERE oom_name LIKE 'Ruang Teori%';

-- Selain Lab dan Ruang Teori ke PIC 2
UPDATE ooms SET pic_id = (SELECT id FROM users WHERE username = 'pic2' LIMIT 1) WHERE oom_name NOT LIKE 'Lab%' AND oom_name NOT LIKE 'Ruang Teori%';