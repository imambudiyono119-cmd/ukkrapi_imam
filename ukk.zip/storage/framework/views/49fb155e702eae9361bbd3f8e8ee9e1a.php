

<?php $__env->startSection('content'); ?>
    <div class="space-y-4">
        <section class="rounded-2xl bg-white p-5 shadow-sm">
            <h2 class="mb-4 text-xl font-bold">Tambah anggota</h2>
            <form method="POST" action="<?php echo e(route('master-data.store')); ?>" class="grid grid-cols-1 gap-4 md:grid-cols-2">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="fullname" class="mb-1 block text-sm font-medium">Nama lengkap</label>
                    <input id="fullname" name="fullname" value="<?php echo e(old('fullname')); ?>" required class="w-full rounded-lg border px-3 py-2">
                </div>
                <div>
                    <label for="username" class="mb-1 block text-sm font-medium">Username</label>
                    <input id="username" name="username" value="<?php echo e(old('username')); ?>" autocomplete="username" required class="w-full rounded-lg border px-3 py-2">
                </div>
                <div>
                    <label for="new-email" class="mb-1 block text-sm font-medium">Email pemulihan</label>
                    <input id="new-email" type="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" required class="w-full rounded-lg border px-3 py-2">
                </div>
                <div>
                    <label for="phone_number" class="mb-1 block text-sm font-medium">Nomor WhatsApp</label>
                    <input id="phone_number" name="phone_number" value="<?php echo e(old('phone_number')); ?>" placeholder="628..." class="w-full rounded-lg border px-3 py-2">
                </div>
                <div>
                    <label for="role_id" class="mb-1 block text-sm font-medium">Peran</label>
                    <select id="role_id" name="role_id" required class="w-full rounded-lg border bg-white px-3 py-2">
                        <option value="">Pilih peran</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>" <?php if(old('role_id') == $role->id): echo 'selected'; endif; ?>><?php echo e($role->role_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label for="new-password" class="mb-1 block text-sm font-medium">Password awal</label>
                    <input id="new-password" type="password" name="password" autocomplete="new-password" required class="w-full rounded-lg border px-3 py-2">
                </div>
                <div>
                    <label for="password_confirmation" class="mb-1 block text-sm font-medium">Ulangi password</label>
                    <input id="password_confirmation" type="password" name="password_confirmation" autocomplete="new-password" required class="w-full rounded-lg border px-3 py-2">
                </div>
                <div class="flex items-end">
                    <button type="submit" class="rounded-lg bg-sky-700 px-4 py-2 font-semibold text-white hover:bg-sky-800">Tambah anggota</button>
                </div>
            </form>
        </section>

        <section class="overflow-hidden rounded-2xl bg-white shadow-sm">
            <div class="border-b px-5 py-4">
                <h2 class="text-lg font-bold">Daftar anggota</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-slate-200 text-left text-sm">
                    <thead class="bg-slate-50 text-slate-600">
                        <tr>
                            <th class="px-4 py-3 font-semibold">Nama</th>
                            <th class="px-4 py-3 font-semibold">Username</th>
                            <th class="px-4 py-3 font-semibold">Peran</th>
                            <th class="min-w-64 px-4 py-3 font-semibold">Email pemulihan</th>
                            <th class="min-w-72 px-4 py-3 font-semibold">Password</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="align-top">
                                <td class="px-4 py-3 font-medium text-slate-900"><?php echo e($member->fullname); ?></td>
                                <td class="px-4 py-3"><?php echo e($member->username); ?></td>
                                <td class="px-4 py-3">
                                    <form method="POST" action="<?php echo e(route('master-data.role', $member)); ?>" class="flex min-w-48 gap-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <select name="role_id" aria-label="Peran <?php echo e($member->fullname); ?>" required class="min-w-0 flex-1 rounded-lg border px-2 py-1.5">
                                            <?php if(! $roles->contains('id', $member->role_id)): ?>
                                                <option value="<?php echo e($member->role_id); ?>" selected disabled><?php echo e($member->role->role_name); ?> (pilih peran baru)</option>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->id); ?>" <?php if($member->role_id === $role->id): echo 'selected'; endif; ?>><?php echo e($role->role_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <button type="submit" class="rounded-lg border border-slate-300 px-3 py-1.5 font-medium hover:bg-slate-50">Simpan</button>
                                    </form>
                                </td>
                                <td class="px-4 py-3">
                                    <form method="POST" action="<?php echo e(route('master-data.email', $member)); ?>" class="flex min-w-56 gap-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="email" name="email" value="<?php echo e($member->email); ?>" aria-label="Email pemulihan <?php echo e($member->fullname); ?>" required class="min-w-0 flex-1 rounded-lg border px-2 py-1.5">
                                        <button type="submit" title="Simpan email" class="rounded-lg border border-slate-300 px-3 py-1.5 font-medium hover:bg-slate-50">Simpan</button>
                                    </form>
                                </td>
                                <td class="px-4 py-3">
                                    <p class="mb-2 text-xs text-slate-500">Password saat ini tidak dapat dilihat.</p>
                                    <form method="POST" action="<?php echo e(route('master-data.password', $member)); ?>" class="space-y-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="password" name="password" autocomplete="new-password" placeholder="Password baru" aria-label="Password baru <?php echo e($member->fullname); ?>" required class="w-full rounded-lg border px-2 py-1.5">
                                        <input type="password" name="password_confirmation" autocomplete="new-password" placeholder="Ulangi password baru" aria-label="Ulangi password baru <?php echo e($member->fullname); ?>" required class="w-full rounded-lg border px-2 py-1.5">
                                        <button type="submit" class="rounded-lg bg-slate-800 px-3 py-1.5 font-medium text-white hover:bg-slate-700">Atur ulang</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="px-4 py-8 text-center text-slate-500">Belum ada anggota.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\OWNER\Herd\ukk\resources\views/master-data/index.blade.php ENDPATH**/ ?>