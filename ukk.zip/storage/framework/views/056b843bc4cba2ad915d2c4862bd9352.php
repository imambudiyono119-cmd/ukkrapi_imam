

<?php $__env->startSection('content'); ?>
    <div class="w-full max-w-md rounded-2xl bg-white p-6 shadow-lg">
        <h1 class="mb-2 text-2xl font-bold">Lupa password?</h1>
        <p class="mb-6 text-sm text-slate-500">Masukkan email pemulihan akun Anda.</p>

        <?php if(session('status')): ?>
            <p class="mb-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-800"><?php echo e(session('status')); ?></p>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('password.email')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>
            <div>
                <label for="email" class="mb-1 block text-sm font-medium">Email</label>
                <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" required class="w-full rounded-xl border px-3 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500">
            </div>
            <button type="submit" class="w-full rounded-xl bg-sky-600 py-3 font-semibold text-white">Kirim tautan reset</button>
        </form>

        <a href="<?php echo e(route('login')); ?>" class="mt-4 block text-center text-sm font-medium text-sky-700 hover:underline">Kembali ke login</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\OWNER\Herd\ukk\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>