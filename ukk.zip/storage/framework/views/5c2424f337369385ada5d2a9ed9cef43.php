

<?php $__env->startSection('content'); ?>
    <div class="space-y-4">
        <?php if($eventNotifications->isNotEmpty()): ?>
            <section class="rounded-2xl border border-sky-200 bg-sky-50 p-4 shadow-sm">
                <h3 class="mb-3 font-semibold text-sky-900">Notifikasi jadwal</h3>
                <?php $__currentLoopData = $eventNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="mb-2 border-b border-sky-200 pb-2 text-sm text-sky-900 last:mb-0 last:border-0 last:pb-0">
                        <?php echo e($notification->data['message'] ?? 'Ada pembaruan pada jadwal Anda.'); ?>

                    </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php endif; ?>

        <?php if($user->isAdmin()): ?>
            <section class="bg-white rounded-2xl p-4 shadow-sm">
                <h3 class="font-semibold mb-3">Notifikasi pengajuan jadwal</h3>
                <?php $__empty_1 = true; $__currentLoopData = $pendingScheduleRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendingEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <details class="mb-2 border-b pb-2 last:border-b-0">
                        <summary class="cursor-pointer font-medium">
                            <?php echo e($pendingEvent->pic?->fullname ?? 'Pengguna'); ?> mengajukan “<?php echo e($pendingEvent->event_name); ?>”
                            pada <?php echo e($pendingEvent->date); ?> (<?php echo e(substr($pendingEvent->start_time, 0, 5)); ?> - <?php echo e(substr($pendingEvent->end_time, 0, 5)); ?>)
                        </summary>
                        <div class="mt-3 space-y-3 pl-4">
                            <p class="text-sm text-slate-600"><?php echo e($pendingEvent->room?->room_name); ?><?php echo e($pendingEvent->room?->location ? ' - '.$pendingEvent->room->location : ''); ?></p>
                            <div class="flex flex-wrap gap-2">
                                <form method="POST" action="<?php echo e(route('events.decision', $pendingEvent)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="disetujui">
                                    <button type="submit" class="rounded-lg bg-emerald-700 px-3 py-2 text-sm font-medium text-white">Setujui</button>
                                </form>
                                <details>
                                    <summary class="cursor-pointer rounded-lg bg-red-700 px-3 py-2 text-sm font-medium text-white">Tolak</summary>
                                    <form method="POST" action="<?php echo e(route('events.decision', $pendingEvent)); ?>" class="mt-3 space-y-3 rounded-lg border border-red-200 p-3">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="status" value="ditolak">
                                        <div>
                                            <label for="rejection_reason_<?php echo e($pendingEvent->id); ?>" class="mb-1 block text-sm font-medium">Alasan penolakan</label>
                                            <textarea id="rejection_reason_<?php echo e($pendingEvent->id); ?>" name="rejection_reason" rows="3" maxlength="1000" required class="w-full rounded-lg border px-3 py-2"></textarea>
                                        </div>
                                        <button type="submit" class="rounded-lg bg-red-700 px-3 py-2 text-sm font-medium text-white">Kirim penolakan</button>
                                    </form>
                                </details>
                                <details class="w-full">
                                    <summary class="inline-block cursor-pointer rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium">Pindahkan</summary>
                                    <form method="POST" action="<?php echo e(route('events.update', $pendingEvent)); ?>" class="mt-3 grid grid-cols-1 gap-3 rounded-lg border border-slate-200 p-3 sm:grid-cols-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="event_name" value="<?php echo e($pendingEvent->event_name); ?>">
                                        <div>
                                            <label class="mb-1 block text-sm">Ruang baru</label>
                                            <select name="room_id" class="w-full rounded-lg border px-3 py-2" required>
                                                <?php $__currentLoopData = $moveRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($roomOption->id); ?>" <?php if($roomOption->id === $pendingEvent->room_id): echo 'selected'; endif; ?>><?php echo e($roomOption->room_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="mb-1 block text-sm">Tanggal baru</label>
                                            <input type="date" name="date" value="<?php echo e($pendingEvent->date); ?>" class="w-full rounded-lg border px-3 py-2" required>
                                        </div>
                                        <div>
                                            <label class="mb-1 block text-sm">Mulai</label>
                                            <input type="time" name="start_time" value="<?php echo e(substr($pendingEvent->start_time, 0, 5)); ?>" class="w-full rounded-lg border px-3 py-2" required>
                                        </div>
                                        <div>
                                            <label class="mb-1 block text-sm">Selesai</label>
                                            <input type="time" name="end_time" value="<?php echo e(substr($pendingEvent->end_time, 0, 5)); ?>" class="w-full rounded-lg border px-3 py-2" required>
                                        </div>
                                        <div class="sm:col-span-2">
                                            <label class="mb-1 block text-sm">Alasan pemindahan</label>
                                            <input type="text" name="move_reason" class="w-full rounded-lg border px-3 py-2" maxlength="1000" required>
                                        </div>
                                        <button type="submit" class="rounded-lg bg-sky-700 px-3 py-2 text-sm font-medium text-white sm:col-span-2">Simpan pemindahan</button>
                                    </form>
                                </details>
                            </div>
                        </div>
                    </details>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-sm text-slate-500">Tidak ada pengajuan jadwal yang menunggu.</p>
                <?php endif; ?>
            </section>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\OWNER\Herd\ukk\resources\views/dashboard.blade.php ENDPATH**/ ?>