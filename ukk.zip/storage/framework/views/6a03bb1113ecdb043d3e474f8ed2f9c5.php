

<?php $__env->startSection('content'); ?>
    <div class="w-full max-w-md rounded-2xl bg-white p-6 shadow-lg">
        <h1 class="mb-2 text-2xl font-bold">Atur ulang password</h1>
        <p class="mb-6 text-sm text-slate-500">Buat password baru untuk akun Anda.</p>

        <form method="POST" action="<?php echo e(route('password.update')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($token); ?>">
            <div>
                <label for="email" class="mb-1 block text-sm font-medium">Email</label>
                <input id="email" type="email" name="email" value="<?php echo e(old('email', $email)); ?>" autocomplete="email" required class="w-full rounded-xl border px-3 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500">
            </div>
            <div>
                <label for="password" class="mb-1 block text-sm font-medium">Password baru</label>
                <input id="password" type="password" name="password" autocomplete="new-password" required class="w-full rounded-xl border px-3 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500">
            </div>
            <div>
                <label for="password_confirmation" class="mb-1 block text-sm font-medium">Ulangi password baru</label>
                <input id="password_confirmation" type="password" name="password_confirmation" autocomplete="new-password" required class="w-full rounded-xl border px-3 py-3 focus:outline-none focus:ring-2 focus:ring-sky-500">
            </div>
            <button type="submit" class="w-full rounded-xl bg-sky-600 py-3 font-semibold text-white">Simpan password baru</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\OWNER\Herd\ukk\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>