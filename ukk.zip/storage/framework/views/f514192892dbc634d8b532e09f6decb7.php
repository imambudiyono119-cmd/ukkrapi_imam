

<?php $__env->startSection('content'); ?>
    <div class="bg-white rounded-2xl p-4 shadow-sm">
        <h2 class="text-xl font-bold mb-4">Pengaduan</h2>
        <form method="POST" action="<?php echo e(route('complaints.store')); ?>" enctype="multipart/form-data" class="space-y-4 mb-6">
            <?php echo csrf_field(); ?>
            <?php if($selectedEvent): ?>
                <input type="hidden" name="event_id" value="<?php echo e($selectedEvent->id); ?>">
                <input type="hidden" name="room_id" value="<?php echo e($selectedEvent->room_id); ?>">
                <div class="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-900">
                    Pengaduan terkait peminjaman <strong><?php echo e($selectedEvent->event_name); ?></strong>
                    di <?php echo e($selectedEvent->room?->room_name); ?> pada <?php echo e($selectedEvent->date); ?>.
                </div>
            <?php else: ?>
                <div>
                    <label class="block text-sm font-medium mb-1">Ruang</label>
                    <select name="room_id" class="w-full border rounded-xl px-3 py-2" required>
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($room->id); ?>" <?php if((string) old('room_id') === (string) $room->id): echo 'selected'; endif; ?>><?php echo e($room->room_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php endif; ?>
            <div>
                <label class="block text-sm font-medium mb-1">Deskripsi</label>
                <textarea name="description" class="w-full border rounded-xl px-3 py-2" rows="4" required><?php echo e(old('description')); ?></textarea>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Foto Bukti</label>
                <input type="file" name="photo" accept="image/*" class="w-full border rounded-xl px-3 py-2">
            </div>
            <button class="bg-rose-600 text-white px-4 py-2 rounded-xl">Kirim Pengaduan</button>
        </form>

        <form method="GET" action="<?php echo e(route('complaints.index')); ?>" class="mb-4 flex flex-wrap items-end gap-2">
            <?php if($selectedEvent): ?>
                <input type="hidden" name="event_id" value="<?php echo e($selectedEvent->id); ?>">
            <?php endif; ?>
            <div class="min-w-60 flex-1">
                <label for="complaint-search" class="mb-1 block text-sm font-medium">Cari pengaduan, ruang, pemohon, atau kegiatan</label>
                <input
                    id="complaint-search"
                    type="search"
                    name="search"
                    value="<?php echo e($search); ?>"
                    maxlength="100"
                    class="w-full rounded-xl border px-3 py-2"
                    placeholder="Masukkan kata kunci"
                >
            </div>
            <div>
                <label for="complaint-status" class="mb-1 block text-sm font-medium">Status penanganan</label>
                <select id="complaint-status" name="status" class="rounded-xl border px-3 py-2">
                    <option value="<?php echo e(\App\Models\Complaint::STATUS_PENDING); ?>" <?php if($status === \App\Models\Complaint::STATUS_PENDING): echo 'selected'; endif; ?>>Belum Diperbaiki</option>
                    <option value="<?php echo e(\App\Models\Complaint::STATUS_PARTS); ?>" <?php if($status === \App\Models\Complaint::STATUS_PARTS): echo 'selected'; endif; ?>>Menunggu Spare Part</option>
                    <option value="<?php echo e(\App\Models\Complaint::STATUS_DONE); ?>" <?php if($status === \App\Models\Complaint::STATUS_DONE): echo 'selected'; endif; ?>>Sudah Diperbaiki</option>
                    <option value="all" <?php if($status === 'all'): echo 'selected'; endif; ?>>Semua</option>
                </select>
            </div>
            <button type="submit" class="rounded-xl bg-sky-700 px-4 py-2 font-medium text-white">Terapkan</button>
        </form>

        <div class="space-y-3">
            <?php $__empty_1 = true; $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="border rounded-xl p-3">
                    <div class="flex justify-between">
                        <strong><?php echo e($complaint->room?->room_name); ?></strong>
                        <span class="text-xs bg-slate-200 px-2 py-1 rounded"><?php echo e($complaint->status_repair); ?></span>
                    </div>
                    <?php if($complaint->event): ?>
                        <p class="mt-1 text-xs text-slate-500">
                            Peminjaman: <?php echo e($complaint->event->event_name); ?> • <?php echo e($complaint->event->date); ?>

                        </p>
                    <?php endif; ?>
                    <p class="text-sm mt-2"><?php echo e($complaint->description); ?></p>
                    <?php if($complaint->photo_path): ?>
                        <img
                            src="<?php echo e(\Illuminate\Support\Facades\Storage::disk('public')->url($complaint->photo_path)); ?>"
                            alt="Foto bukti pengaduan"
                            class="mt-3 max-h-64 rounded-lg object-contain"
                        >
                    <?php endif; ?>

                    <?php if(auth()->user()->isAdmin() || auth()->user()->isPic()): ?>
                        <form method="POST" action="<?php echo e(route('complaints.updateStatus', $complaint)); ?>" class="mt-3 flex gap-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <select name="status_repair" class="border rounded-xl px-2 py-2 flex-1">
                                <?php $__currentLoopData = ['Belum Diperbaiki', 'Menunggu Spare Part', 'Sudah Diperbaiki']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status); ?>" <?php if($complaint->status_repair === $status): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button class="bg-sky-600 text-white px-3 py-2 rounded-xl">Update</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-slate-500">Belum ada pengaduan.</p>
            <?php endif; ?>
        </div>
        <div class="mt-4"><?php echo e($complaints->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\OWNER\Herd\ukk\resources\views/complaints/index.blade.php ENDPATH**/ ?>