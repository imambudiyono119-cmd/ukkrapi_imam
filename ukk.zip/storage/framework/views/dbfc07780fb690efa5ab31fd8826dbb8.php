<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6/index.global.min.js"></script>
</head>
<body class="bg-slate-100 text-slate-800">
    <div class="max-w-7xl mx-auto px-4 py-4">
        <header class="flex items-center justify-between bg-white rounded-2xl shadow-sm px-4 py-3 mb-4">
            <div class="flex items-center gap-3">
                <img src="<?php echo e(asset('images/logo-smkn-1-bantul.png')); ?>" alt="Logo SMKN 1 Bantul" class="h-12 w-12 object-contain">
                <div>
                    <h1 class="font-bold text-lg">RAPI-Sekolah</h1>
                    <p class="text-xs text-slate-500">Agenda & fasilitas sekolah</p>
                </div>
            </div>
            <div class="flex items-center gap-3">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('profile')); ?>" class="text-sm text-slate-700"><?php echo e(auth()->user()->fullname); ?></a>
                    <form action="<?php echo e(route('logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="bg-slate-800 text-white px-3 py-2 rounded-lg text-sm">Logout</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="bg-sky-600 text-white px-3 py-2 rounded-lg text-sm">Login</a>
                <?php endif; ?>
            </div>
        </header>

        <main class="grid grid-cols-1 gap-4 lg:grid-cols-12">
            <aside class="lg:col-span-3 bg-white rounded-2xl shadow-sm p-4">
                <nav class="space-y-2 text-sm">
                    <?php if(auth()->user()?->isGuru()): ?>
                        <a href="<?php echo e(route('calendar.public')); ?>" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Kalender</a>
                        <a href="<?php echo e(route('complaints.index')); ?>" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Pengaduan</a>
                    <?php else: ?>
                        <?php if (! (request()->routeIs('home', 'calendar.public'))): ?>
                            <a href="<?php echo e(route('dashboard')); ?>" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Dashboard</a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('calendar.public')); ?>" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Kalender</a>
                        <?php if(! auth()->user()?->isStudent()): ?>
                            <a href="<?php echo e(route('complaints.index')); ?>" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Pengaduan</a>
                        <?php endif; ?>
                        <?php if(auth()->user()?->isAdmin()): ?>
                            <a href="<?php echo e(route('master-data.index')); ?>" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Master Data</a>
                            <a href="<?php echo e(route('reports.daily')); ?>" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Laporan Harian</a>
                            <a href="<?php echo e(route('reports.monthly')); ?>" class="block px-3 py-2 rounded-lg hover:bg-slate-100">Laporan Bulanan</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </nav>
            </aside>
            <section class="lg:col-span-9">
                <?php $notifications = $notifications ?? []; ?>
                <?php if(!empty($notifications)): ?>
                    <div class="mb-4 space-y-2">
                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="rounded-xl border border-sky-200 bg-sky-50 text-sky-800 px-3 py-2 text-sm">
                                <?php echo e($notification['message'] ?? ''); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="mb-4 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-800 px-3 py-2 text-sm">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="mb-4 rounded-xl bg-red-100 border border-red-300 text-red-800 px-3 py-2 text-sm">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\Users\OWNER\Herd\ukk\resources\views/layouts/app.blade.php ENDPATH**/ ?>