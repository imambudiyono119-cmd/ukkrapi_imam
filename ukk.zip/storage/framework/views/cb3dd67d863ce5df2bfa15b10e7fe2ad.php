<?php echo e($slot); ?>

<?php /**PATH C:\Users\OWNER\Herd\ukk\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>